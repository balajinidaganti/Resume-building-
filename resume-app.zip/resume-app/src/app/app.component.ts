import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
//   resume = {
//   name:'Nidaganti Balaji',
//   email:'balajinidaganti@gmail.com',
//   experience:'Worked as a Assistant Professor in Sai Ganpathi Engineering college,Visakhapatnam',
//   objective:'Critical thinker with an instinct for design who plans to use these qualities in a front-end developer role that allows me to further develop my skills',
//   skills:['HTML','CSS','Javascript','Angular','Github','Devops Tools like CI/CD pipelines,Maven,Docker','AWS services-EC2,S3,ELB'],
//   education: [
//     {
//       school:'z p high school,sontyam',
//       program: '10th',
//       from: 2008,
//       to:2009
//     },
//     {
//       school:'Narayana junior college',
//       program: 'Intermediate',
//       from: 2009,
//       to:2011
//     },
//     {
//       school:'VITAM college of engg.',
//       program: 'B.Tech',
//       from: 2011,
//       to:2015
//     },
//     {
//       school:'MVGR college',
//       program: 'M.Tech',
//       from: 2017,
//       to:2019
//     }
//   ],
// }

  resume: any=null;
  constructor(private http: HttpClient){}
  ngOnInit(): void {
  this.http.get('https://gist.githubusercontent.com/balajimahesh/3b95a9bd55bdb812f529141ef117fbb4/raw/bc6ae8c23ca4f3608181cc8e719b75d5be58d73b/resume.json')
  .subscribe(res => {
  this.resume=res;
   console.log(res);
   })
}
}
